<?php
/**
 * WARNING: This file is part of the Mountain theme. DO NOT edit
 * this file under any circumstances.
 */

/**
 * Prevent direct access to this file
 */
defined( 'ABSPATH' ) or die();

// Register projects shortcode
add_shortcode( 'projects_grid', 'mountain_shortcode_projects_grid' );
add_shortcode( 'projects_justify', 'mountain_shortcode_projects_justify' );

/**
 * Handler function to render projects shortcode
 * 
 * @param   mixed   $atts     Shortcode attributes
 * @param   string  $content  Shortcode inner content
 * @return  stirng
 */
function mountain_shortcode_projects_grid( $atts, $content = null ) {
	$atts = shortcode_atts( array(
		'category'        => '',
		'tag'             => '',
		'exclude'         => '',
		'layout'          => 'grid',
		'columns'         => 4,
		'limit'           => 8,
		'filter'          => 'yes',
		'filter_by'       => 'category',
		'order_by'        => 'date',
		'order_direction' => 'DESC',
		'permalinks'      => 'yes',
		'css'             => '',
		'class'           => ''
	), $atts );

	$args = array(
		'post_type'      => 'nproject',
		'posts_per_page' => intval( $atts['limit'] ),
		'tax_query'      => array()
	);

	$layout = in_array( $atts['layout'], array( 'grid', 'masonry', 'gallery' ) )
		? $atts['layout'] : 'grid';

	$thumbnail_sizes = array(
		'grid'    => 'thumbnail-medium-crop',
		'masonry' => 'thumbnail-medium',
		'gallery' => 'thumbnail-medium-crop'
	);

	// Filter by categories
	if ( ! empty( $atts['category'] ) ) {
		$args['tax_query'][] = array(
			'taxonomy' => 'nproject-category',
			'terms'    => $atts['category'],
			'field'    => 'slug',
			'operator' => 'IN'
		);
	}

	// Filter by tags
	if ( ! empty( $atts['tag'] ) ) {
		$args['tax_query'][] = array(
			'taxonomy' => 'nproject-tag',
			'terms'    => $atts['tag'],
			'field'    => 'slug',
			'operator' => 'IN'
		);
	}

	if ( ! empty( $atts['exclude'] ) ) {
		$exclude = $atts['exclude'];

		if ( ! is_array( $exclude ) )
			$exclude = explode( ',', $exclude );

		$args['post__not_in'] = $exclude;
	}

	if ( in_array( strtolower( $atts['order_by'] ),
			array( 'none', 'id', 'author', 'title', 'name', 'type', 'date', 'modified', 'parent', 'rand', 'comment_count', 'menu_order' ) ) ) {
		$args['orderby'] = $atts['order_by'];
		$args['order']   = in_array( strtolower( $atts['order_direction'] ), array( 'desc', 'asc' ) ) 
			? $atts['order_direction'] : 'desc';
	}

	$classes = 'projects projects-' . $layout;
	$query   = new WP_Query( $args );

	// Fetching the taxonomy data that will be
	// show for filtering projects
	if ( $atts['filter'] == 'yes' ) {
		$classes .= ' projects-has-filter';
		$terms    = array();
		$taxonomy = in_array( $atts['filter_by'], array( 'tag', 'category' ) )
			? 'nproject-' . $atts['filter_by']
			: 'nproject-category';

		while ( $query->have_posts() ) {
			$query->next_post();

			if ( $post_terms = get_the_terms( $query->post->ID, $taxonomy ) )
				foreach ( $post_terms as $term )
					$terms[ $term->term_id ] = $term;
		}

		$query->rewind_posts();
	}

	ob_start();
	?>

		<?php if ( $query->have_posts() ): ?>

			<div class="<?php __esc_attr( $classes ) ?>" data-columns="<?php echo (int) $atts['columns'] ?>">
				<div class="projects-wrap">
					<?php if ( ! empty( $terms ) ): ?>
						<div class="projects-filter">
							<a href="javascript:;" class="projects-filter-toggler">
								<span><?php _e( 'Toggle Filter', 'mountain' ) ?></span>
							</a>

							<ul>
								<li data-filter="*" class="active">
									<a href=""><?php _e( 'All', 'mountain' ) ?></a>
								</li>
								<?php foreach ( $terms as $id => $term ): ?>
									<li data-filter=".nproject-<?php __esc_attr( $atts['filter_by'] ) ?>-<?php __esc_attr( $term->slug ) ?>">
										<a href="<?php echo __esc_url( get_term_link( $term ) ) ?>"><?php __esc_html( $term->name ) ?></a>
									</li>
								<?php endforeach ?>
							</ul>
						</div>
					<?php endif ?>

					<div class="projects-items">
						<?php while ( $query->have_posts() ): $query->the_post(); ?>

							<div class="<?php __esc_attr( join( ' ', get_post_class( 'project' ) ) ) ?>">
								<div class="project-wrap">
									<figure class="project-thumbnail">
										<?php if ( $atts['permalinks'] == 'yes' ): ?>
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail( $thumbnail_sizes[ $layout ], array( 'itemprop' => 'image' ) ) ?>
											</a>
										<?php else: ?>
											<a>
												<?php the_post_thumbnail( $thumbnail_sizes[ $layout ], array( 'itemprop' => 'image' ) ) ?>
											</a>
										<?php endif ?>
									</figure>

									<div class="project-info">
										<div class="project-info-wrap">
											<h3 class="project-title" itemprop="name headline">
												<?php if ( $atts['permalinks'] == 'yes' ): ?>
													<a href="<?php the_permalink() ?>">
														<?php the_title() ?>
													</a>
												<?php else: ?>
													<a>
														<?php the_title() ?>
													</a>
												<?php endif ?>
											</h3>
											<ul class="project-categories">
												<?php the_terms( get_the_ID(), nProjects::TYPE_CATEGORY, '<li>', '</li><li>', '</li>' ) ?>
											</ul>
										</div>
									</div>
								</div>
							</div>

						<?php endwhile ?>
					</div>
				</div>
			</div>

		<?php endif ?>

	<?php
	wp_reset_postdata();

	return ob_get_clean();
}


/**
 * Handler function to render projects shortcode
 * 
 * @param   mixed   $atts     Shortcode attributes
 * @param   string  $content  Shortcode inner content
 * @return  stirng
 */
function mountain_shortcode_projects_justify( $atts, $content = null ) {
	$atts = shortcode_atts( array(
		'category'        => '',
		'tag'             => '',
		'exclude'         => '',
		'limit'           => 8,
		'order_by'        => 'date',
		'order_direction' => 'DESC',
		'permalinks'      => 'yes',
		'css'             => '',
		'class'           => ''
	), $atts );

	$args = array(
		'post_type'      => 'nproject',
		'posts_per_page' => intval( $atts['limit'] ),
		'tax_query'      => array()
	);

	// Filter by categories
	if ( ! empty( $atts['category'] ) ) {
		$args['tax_query'][] = array(
			'taxonomy' => 'nproject-category',
			'terms'    => $atts['category'],
			'field'    => 'slug',
			'operator' => 'IN'
		);
	}

	// Filter by tags
	if ( ! empty( $atts['tag'] ) ) {
		$args['tax_query'][] = array(
			'taxonomy' => 'nproject-tag',
			'terms'    => $atts['tag'],
			'field'    => 'slug',
			'operator' => 'IN'
		);
	}

	if ( ! empty( $atts['exclude'] ) ) {
		$exclude = $atts['exclude'];

		if ( ! is_array( $exclude ) )
			$exclude = explode( ',', $exclude );

		$args['post__not_in'] = $exclude;
	}

	if ( in_array( strtolower( $atts['order_by'] ),
			array( 'none', 'id', 'author', 'title', 'name', 'type', 'date', 'modified', 'parent', 'rand', 'comment_count', 'menu_order' ) ) ) {
		$args['orderby'] = $atts['order_by'];
		$args['order']   = in_array( strtolower( $atts['order_direction'] ), array( 'desc', 'asc' ) ) 
			? $atts['order_direction'] : 'desc';
	}

	$classes = 'projects projects-justify';
	$query   = new WP_Query( $args );

	ob_start();
	?>

		<?php if ( $query->have_posts() ): ?>

			<div class="<?php __esc_attr( $classes ) ?>">
				<div class="projects-wrap">
					<div class="projects-items flex-images">
						<?php while ( $query->have_posts() ): $query->the_post();
							$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumbnail-medium' );
							?>

							<div class="<?php __esc_attr( join( ' ', get_post_class( 'project item' ) ) ) ?>" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"
								data-w="<?php __esc_attr( $thumbnail[1] ) ?>" data-h="<?php __esc_attr( $thumbnail[2] ) ?>">
								
								<?php if ( $atts['permalinks'] == 'yes' ): ?>
									<a href="<?php the_permalink() ?>">
										<?php the_post_thumbnail( 'thumbnail-medium', array( 'itemprop' => 'image' ) ) ?>
									</a>
								<?php else: ?>
									<a>
										<?php the_post_thumbnail( 'thumbnail-medium', array( 'itemprop' => 'image' ) ) ?>
									</a>
								<?php endif ?>

								<div class="project-info">
									<div class="project-info-wrap">
										<h3 class="project-title" itemprop="name headline">
											<?php if ( $atts['permalinks'] == 'yes' ): ?>
												<a href="<?php the_permalink() ?>">
													<?php the_title() ?>
												</a>
											<?php else: ?>
												<a>
													<?php the_title() ?>
												</a>
											<?php endif ?>
										</h3>
										<ul class="project-categories">
											<?php the_terms( get_the_ID(), nProjects::TYPE_CATEGORY, '<li>', '</li><li>', '</li>' ) ?>
										</ul>
									</div>
								</div>
							</div>

						<?php endwhile ?>
					</div>
				</div>
			</div>

		<?php endif ?>

	<?php
	wp_reset_postdata();

	return ob_get_clean();
}
