<?php
/**
 * WARNING: This file is part of the plugin. DO NOT edit
 * this file under any circumstances.
 */

/**
 * Plugin Name: Shortcodes for Mountain
 * Plugin URI:  http://linethemes.com/
 * Description: The shortcodes for Mountain theme
 * Author:      LineThemes
 * Version:     1.0.2
 * Author URI: http://linethemes.com/
 */
defined( 'ABSPATH' ) or die();

/**
 * Auto load all includable files
 */
foreach ( glob( plugin_dir_path( __FILE__ ) . '/includes/*.php' ) as $file ) {
	include $file;
}
